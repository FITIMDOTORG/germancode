import click
from germancode.parser.parser import parser, ASTBuilder
from germancode.transpiler.python_transpiler import transpile
import subprocess
import tempfile

@click.command()
@click.argument("datei", type=click.Path(exists=True))
def deutsch(datei):
    with open(datei, encoding="utf-8") as f:
        source = f.read()

    tree = parser.parse(source)
    ast = ASTBuilder().transform(tree)
    py_code = transpile(ast)

    with tempfile.NamedTemporaryFile("w", delete=False, suffix=".py") as temp:
        temp.write(py_code)
        temp.flush()
        subprocess.run(["python", temp.name])

if __name__ == "__main__":
    deutsch()
