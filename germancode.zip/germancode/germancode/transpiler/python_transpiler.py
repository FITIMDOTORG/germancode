def transpile(ast_list):
    lines = []
    for stmt in ast_list:
        if stmt["type"] == "zahl":
            lines.append(f"{stmt['var']} = {stmt['value']}")
        elif stmt["type"] == "zeichenkette":
            val = f'"{stmt["value"]}"'
            lines.append(f"{stmt['var']} = {val}")
    return "\n".join(lines)
