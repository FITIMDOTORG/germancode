from lark import Lark, Transformer

with open("germancode/parser/grammar.lark", encoding="utf-8") as f:
    grammar = f.read()

parser = Lark(grammar, parser="lalr")

class ASTBuilder(Transformer):
    def assign_stmt(self, items):
        typ, var, val = items
        return {"type": typ, "var": var, "value": val}

    def assign(self, items):
        return items[0]

    def number(self, n):
        return int(n[0])

    def string(self, s):
        return s[0][1:-1]

    def TYPE(self, t):
        return str(t)

    def VAR(self, v):
        return str(v)
