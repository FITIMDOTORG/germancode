# Initialisierungsdatei für germancode
